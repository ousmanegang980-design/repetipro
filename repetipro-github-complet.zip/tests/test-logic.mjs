/* Tests RépétiPro — exécution : node tests/test-logic.mjs */
import { createRequire } from "module";
import { writeFileSync } from "fs";
const L = createRequire(import.meta.url)("../logic.js");

let ok = 0, ko = 0;
function test(nom, fn) { try { fn(); ok++; console.log("✅ " + nom); } catch (e) { ko++; console.log("❌ " + nom + " — " + e.message); } }
function eq(a, b, msg) { if (a !== b) throw new Error((msg || "") + " attendu=" + JSON.stringify(b) + " obtenu=" + JSON.stringify(a)); }
function vrai(c, msg) { if (!c) throw new Error(msg || "condition fausse"); }

/* §20.3–5 : échéances calendaires */
test("Échéance 15/01 -> 15/02", () => eq(L.addOneMonth("2026-01-15"), "2026-02-15"));
test("Échéance 31/01 -> dernier jour de février (2026 non bissextile)", () => eq(L.addOneMonth("2026-01-31"), "2026-02-28"));
test("Échéance 31/01 -> 29/02 en année bissextile", () => eq(L.addOneMonth("2028-01-31"), "2028-02-29"));
test("Échéance 31/03 -> 30/04", () => eq(L.addOneMonth("2026-03-31"), "2026-04-30"));
test("Échéance 22/10 -> 22/11", () => eq(L.addOneMonth("2026-10-22"), "2026-11-22"));
test("Changement d'année 15/12 -> 15/01", () => eq(L.addOneMonth("2026-12-15"), "2027-01-15"));
test("Format JJ/MM/AAAA", () => eq(L.formatDateFR("2026-10-26"), "26/10/2026"));
test("Date invalide rejetée (30/02)", () => eq(L.parseISODate("2026-02-30"), null));

/* §20.6–8 : paiements et soldes (entiers) */
test("Paiement intégral solde=0", () => { const s = L.soldePeriode(25000, [{ montant: 25000 }]); eq(s.solde, 0); eq(s.montantPaye, 25000); });
test("Deux paiements partiels : solde après chaque versement", () => {
  eq(L.soldePeriode(25000, [{ montant: 10000 }]).solde, 15000);
  eq(L.soldePeriode(25000, [{ montant: 10000 }, { montant: 9000 }]).solde, 6000);
});
test("Montant flottant rejeté", () => { let e = false; try { L.assertMontant(10.5); } catch { e = true; } vrai(e); });
test("Format montant avec séparateurs", () => vrai(L.formatMontant(1250000).startsWith("1 250 000")));
test("Surpaiement rejeté par la validation", () => {
  const errs = L.validerPaiement({ periodeId: "p1", montant: 30000, moyenPaiement: "especes", datePaiement: "2026-10-26T10:00" }, 25000);
  vrai(errs.length >= 1, "le surpaiement doit produire une erreur");
});

/* §20.13 : statuts */
const per = { dateEcheance: "2026-11-15", montantDu: 25000, statutManuel: "active" };
test("Statut à venir", () => eq(L.statutPeriode(per, 0, "2026-10-26"), "a_venir"));
test("Statut aujourd'hui", () => eq(L.statutPeriode(per, 0, "2026-11-15"), "aujourd_hui"));
test("Statut en retard", () => eq(L.statutPeriode(per, 0, "2026-11-20"), "en_retard"));
test("Statut partiel", () => eq(L.statutPeriode(per, 10000, "2026-10-26"), "partiel"));
test("Statut partiel en retard", () => eq(L.statutPeriode(per, 10000, "2026-11-20"), "partiel_en_retard"));
test("Statut payée seulement si solde=0", () => { eq(L.statutPeriode(per, 25000, "2026-11-20"), "payee"); vrai(L.statutPeriode(per, 24999, "2026-10-26") !== "payee"); });
test("Statuts manuels annulée/suspendue prioritaires", () => {
  eq(L.statutPeriode({ ...per, statutManuel: "annulee" }, 25000, "2026-10-26"), "annulee");
  eq(L.statutPeriode({ ...per, statutManuel: "suspendue" }, 0, "2026-10-26"), "suspendue");
});

/* §20.11 : numéros de reçu uniques */
test("Numéro de reçu formaté et croissant", () => { eq(L.numeroRecu(2026, 1), "RP-2026-000001"); eq(L.numeroRecu(2026, 42), "RP-2026-000042"); });

/* §20.9–10 : reçu + PDF réel */
const snap = { activite: "RépétiPro — M. Dupont", telephoneActivite: "+228 90 00 00 00", coordonneesActivite: "Lomé, Togo",
  numero: "RP-2026-000001", statut: "valide", datePaiementFR: "26/10/2026", eleveNom: "Aïcha Martin", eleveClasse: "3e",
  matière: "Mathématiques", periodeDebutFR: "15/10/2026", periodeEcheanceFR: "15/11/2026",
  montantRecu: 10000, montantDu: 25000, payeAvant: 0, soldeApres: 15000, moyenLibelle: "Mobile Money", reference: "MM-123", note: "" };
test("Lignes du reçu complètes", () => {
  const txt = L.lignesRecu(snap, "FCFA").map((l) => l.text || "").join("\n");
  for (const attendu of ["REÇU DE PAIEMENT", "RP-2026-000001", "Aïcha Martin", "Généré par RépétiPro"]) vrai(txt.includes(attendu), "manque : " + attendu);
});
test("PDF généré : en-tête, EOF et taille", () => {
  const pdf = L.genererPDF("RépétiPro", L.lignesRecu(snap, "FCFA"), "A4");
  const head = String.fromCharCode(...pdf.slice(0, 8));
  eq(head, "%PDF-1.4"); vrai(pdf.length > 800, "PDF trop petit");
  writeFileSync(new URL("./exemple-recu.pdf", import.meta.url), pdf);
});
test("PDF compact généré", () => vrai(L.genererPDF("RépétiPro", L.lignesRecu(snap, "FCFA"), "compact").length > 800));

/* §20.16 : sauvegarde — intégrité */
test("Sauvegarde valide acceptée, corrompue rejetée", () => {
  const data = { eleves: [], repetitions: [], periodes: [{ id: "p1" }], paiements: [], recus: [] };
  const sauvegarde = { app: "RépétiPro", version: 1, data, checksum: L.checksum(JSON.stringify(data)) };
  eq(L.validerSauvegarde(sauvegarde).length, 0);
  vrai(L.validerSauvegarde({ ...sauvegarde, checksum: "deadbeef" }).length >= 1);
});

/* §20.17 : rappels sans doublon (clés stables) */
test("Rappels : une seule clé par type et par période", () => {
  const calc = [{ periode: { id: "p1", dateEcheance: "2026-10-29" }, statut: "a_venir" }];
  const prefs = { avant: true, jourJ: true, apres: true, delaiApres: 2 };
  const r = L.rappelsDus(calc, prefs, "2026-10-26");
  eq(r.length, 1); eq(r[0].cle, "p1:avant3:2026-10-29");
  eq(L.rappelsDus(calc, prefs, "2026-10-27").length, 0); // ni J-3, ni J, ni J+2
});

/* Validation élève */
test("Élève sans nom rejeté", () => vrai(L.validerEleve({ nomComplet: "", classe: "3e", cycle: "college" }).length >= 1));
test("Élève valide accepté", () => eq(L.validerEleve({ nomComplet: "Aïcha Martin", classe: "3e", cycle: "college", tarifMensuel: 25000 }).length, 0));

console.log("\nRésultat : " + ok + " réussis, " + ko + " échoués.");
if (ko > 0) process.exit(1);
